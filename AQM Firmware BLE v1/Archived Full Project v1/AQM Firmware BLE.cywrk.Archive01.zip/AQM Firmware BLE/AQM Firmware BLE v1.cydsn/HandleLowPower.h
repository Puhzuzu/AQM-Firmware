/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#if !defined(HANDLELOWPOWER_H)
#define HANDLELOWPOWER_H
#include <project.h>

/**************************Function Declarations*****************************/
void HandleLowPowerMode(void);
CY_ISR_PROTO(MyISR);
/****************************************************************************/

#endif
    
/* [] END OF FILE */
